package com.hertz.digital.hertzrac.configserver;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.rule.OutputCapture;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.StringUtils;


/**
 * This is the test class acts as Config Server. With the Config Server we have a central place to manage external 
 * properties for applications across all environments.
 * 
 * @author: babita.bansal
 * @last updated date:30 March 2017
 * @version:1.0
 *
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, value = { "eureka.client.enabled:false","spring.profiles.active=native" })
public class ConfigServiceApplicationTests {
	
	@Autowired
	private TestRestTemplate testRestTemplate;	
	
	@Test
	public void configurationAvailable() {
		@SuppressWarnings("rawtypes")
		ResponseEntity<Map> entity = testRestTemplate.getForEntity("/app/native", Map.class);
		assertEquals(HttpStatus.OK, entity.getStatusCode());		
	}
	
	@Test
	public void adminLoads() {
		@SuppressWarnings("rawtypes")
		ResponseEntity<Map> entity = testRestTemplate.getForEntity("/env", Map.class);
		assertEquals(HttpStatus.UNAUTHORIZED, entity.getStatusCode());
	}
	@Rule
    public OutputCapture outputCapture = new OutputCapture();
    
    private static final String SPRING_STARTUP = "root of context hierarchy";

    @Test
    public void contextLoads() {
    }
    
    /*@Test
    public void configClassContext() throws Exception {
    	ConfigServiceApplication.main(getArgs(getClass().getName()));
           assertThat(getOutput()).contains(SPRING_STARTUP);
    }*/
    
    private String[] getArgs(String... args) {
           List<String> list = new ArrayList<>(Arrays.asList(
                        "--spring.main.webEnvironment=false", "--spring.main.showBanner=OFF",
                        "--spring.main.registerShutdownHook=false", "--spring.profiles.active=test"));
           if (args.length > 0) {
                  list.add("--spring.main.sources="
                               + StringUtils.arrayToCommaDelimitedString(args));
           }
           return list.toArray(new String[list.size()]);
    }

    private String getOutput() {
           return this.outputCapture.toString();
    }
	
	

}

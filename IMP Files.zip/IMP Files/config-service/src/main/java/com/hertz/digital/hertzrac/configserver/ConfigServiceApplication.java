package com.hertz.digital.hertzrac.configserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.config.server.EnableConfigServer;


/**
 * This class acts as Config Server. With the Config Server we have a central place to manage external 
 * properties for applications across all environments.
 * This is a regular Spring Boot application with annotation @EnableConfigServer added to enable the config server.
 * @author: babita.bansal
 * @last updated date:29 March 2017
 * @version:1.0
 *
 *
 */
@EnableConfigServer
@SpringBootApplication
@EnableDiscoveryClient
public class ConfigServiceApplication {

	/**
	 * This method is used to start the config server.
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(ConfigServiceApplication.class, args);
	}
}

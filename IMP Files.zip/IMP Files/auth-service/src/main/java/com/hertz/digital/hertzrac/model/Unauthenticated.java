package com.hertz.digital.hertzrac.model;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;


/**
 * 
 * Ant pattern for permited unauthenticated urls
 *
 */

@ConfigurationProperties(prefix = "unauthenticated")
@Component
public class Unauthenticated {
	
	private List<String> permit;

	public List<String> getPermit() {
		return permit;
	}

	public void setPermit(List<String> permit) {
		this.permit = permit;
	}
	

}

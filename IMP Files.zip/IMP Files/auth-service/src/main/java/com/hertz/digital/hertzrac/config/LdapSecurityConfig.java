package com.hertz.digital.hertzrac.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import com.hertz.digital.hertzrac.model.Unauthenticated;

@Configuration
public class LdapSecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Value("${ldap.url}")
    private String ldapUrl;
	
	@Value("${ldap.ldif}")
    private String ldapLdif;
	
	@Value("${ldap.user-dn-patterns}")
    private String ldapUserDnPatterns;
	
	@Value("${ldap.user-search-base}")
    private String ldapUserSearchBase;
	
	@Value("${ldap.group-search-base}")
    private String ldapGroupSearchBase;
	
	@Value("${ldap.group-search-filter}")
    private String ldapGroupSearchFilter;
	
	@Value("${ldap.user-search-filter}")
	private String ldapUserSearchFilter;
	
	@Autowired
	private Unauthenticated unauthenticated;

	@Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth
			.ldapAuthentication()
			.userDnPatterns(ldapUserDnPatterns)
			.contextSource()
			.url(ldapUrl)
			.and()			
			.userSearchFilter(ldapUserSearchFilter);
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean()
            throws Exception {
        return super.authenticationManagerBean();
    }    
 
    
    /**
	 * Provide security so that endpoints are only served if the request is
	 * already authenticated.
	 */
    @Override
	public void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
				.antMatchers(unauthenticated.getPermit().toArray(new String[unauthenticated.getPermit().size()]))
				.permitAll().anyRequest().authenticated();
	}
	
}

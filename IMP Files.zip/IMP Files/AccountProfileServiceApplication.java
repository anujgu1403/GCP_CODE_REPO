package com.hertz.digital.hertzrac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * This class is act as a spring boot class and used to enable the eureka, circuit breaker
 * 
 * @author vijay.bq.kumar
 *
 */
@EnableCircuitBreaker
@SpringBootApplication
@EnableDiscoveryClient
public class AccountProfileServiceApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(AccountProfileServiceApplication.class, args);
	}
}

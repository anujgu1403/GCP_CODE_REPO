package com.hertz.digital.hertzrac.gateway.swagger;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import springfox.documentation.swagger.web.SwaggerResource;

@RunWith(SpringRunner.class)
public class CustomSwaggerResourceProviderV2Test {

	@Test
	public void testGet() {
		CustomSwaggerResourceProviderV2 swagger = new CustomSwaggerResourceProviderV2();
		List<SwaggerResource> swaggerList = swagger.get();
		assertTrue(swaggerList.size() > 0);
	}

}

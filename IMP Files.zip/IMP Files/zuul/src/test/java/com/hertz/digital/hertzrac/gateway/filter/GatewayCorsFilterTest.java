package com.hertz.digital.hertzrac.gateway.filter;

import static com.hertz.digital.hertzrac.gateway.util.Constants.CORRELATION_ID;
import static org.junit.Assert.*;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.Mockito;
import org.springframework.cloud.netflix.zuul.filters.RouteLocator;
import org.springframework.cloud.netflix.zuul.web.ZuulController;
import org.springframework.cloud.netflix.zuul.web.ZuulHandlerMapping;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.filter.CorsFilter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hertz.digital.hertzrac.gateway.filter.GatewayCorsFilter;

@RunWith(SpringRunner.class)
public class GatewayCorsFilterTest {

	private CorsFilter filter;
	private static final String DOMAIN = "http://differentdomain.com ";
	private static final String HEADER = "header1, header2";
	private RouteLocator locator = Mockito.mock(RouteLocator.class);
	private ZuulHandlerMapping mapping = new ZuulHandlerMapping(this.locator, new ZuulController());

	@Before
	public void setup() {
		GatewayCorsFilter gatewayCorsFilter = new GatewayCorsFilter();
		gatewayCorsFilter.setZuulHandlerMapping(mapping);
		filter = gatewayCorsFilter.corsFilter();
	}

	@Test
	public void invalidRequest() throws ServletException, IOException {

		MockHttpServletRequest request = new MockHttpServletRequest(HttpMethod.PUT.name(), "/put.html");
		request.addHeader(HttpHeaders.ORIGIN, DOMAIN);
		MockHttpServletResponse response = new MockHttpServletResponse();

		FilterChain filterChain = (filterRequest,
				filterResponse) -> fail("Invalid requests should not pass through the filter chain");
		
		filter.doFilter(request, response, filterChain);
		checkInvalidRequest(response);
	}

	@Test
	public void validRequest() throws ServletException, IOException {

		MockHttpServletRequest request = new MockHttpServletRequest(HttpMethod.GET.name(), "/get.html");
		request.addHeader(HttpHeaders.ORIGIN, DOMAIN);
		MockHttpServletResponse response = new MockHttpServletResponse();

		FilterChain filterChain = (filterRequest, filterResponse) -> assertEquals(DOMAIN,
				response.getHeader(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN));
		
		filter.doFilter(request, response, filterChain);
	}

	@Test
	public void validPreFlightRequest() throws ServletException, IOException {

		MockHttpServletRequest request = new MockHttpServletRequest(HttpMethod.OPTIONS.name(), "/options.html");
		request.addHeader(HttpHeaders.ORIGIN, DOMAIN);
		request.addHeader(HttpHeaders.ACCESS_CONTROL_REQUEST_METHOD, HttpMethod.GET.name());
		request.addHeader(HttpHeaders.ACCESS_CONTROL_REQUEST_HEADERS, HEADER);
		MockHttpServletResponse response = new MockHttpServletResponse();

		FilterChain filterChain = (filterRequest,
				filterResponse) -> fail("Preflight requests must not be forwarded to the filter chain");
		filter.doFilter(request, response, filterChain);

		assertEquals(DOMAIN, response.getHeader(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN));
		assertEquals(HEADER, response.getHeader(HttpHeaders.ACCESS_CONTROL_ALLOW_HEADERS));
	}

	@Test
	public void invalidPreFlightRequest() throws ServletException, IOException {

		MockHttpServletRequest request = new MockHttpServletRequest(HttpMethod.OPTIONS.name(), "/options.html");
		request.addHeader(HttpHeaders.ORIGIN, "http://differentdomain.com");
		request.addHeader(HttpHeaders.ACCESS_CONTROL_REQUEST_METHOD, HttpMethod.PUT.name());
		request.addHeader(HttpHeaders.ACCESS_CONTROL_REQUEST_HEADERS, HEADER);
		MockHttpServletResponse response = new MockHttpServletResponse();

		FilterChain filterChain = (filterRequest,
				filterResponse) -> fail("Preflight requests must not be forwarded to the filter chain");
		filter.doFilter(request, response, filterChain);

		checkInvalidRequest(response);
	}

	private void checkInvalidRequest(MockHttpServletResponse response) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode jsonRootNode = mapper.readTree(response.getContentAsString());
		String correlationId = jsonRootNode.path(CORRELATION_ID).textValue();
		assertNull(response.getHeader(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN));
		assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
		assertEquals("application/json;charset=UTF-8", response.getContentType());
		assertNotNull(correlationId);
		assertFalse(correlationId.isEmpty());

	}

}

package com.hertz.digital.hertzrac.gateway;

import static com.hertz.digital.hertzrac.util.TestConstants.BRAND;
import static com.hertz.digital.hertzrac.util.TestConstants.CODE;
import static com.hertz.digital.hertzrac.util.TestConstants.CORRELATION_ID;
import static com.hertz.digital.hertzrac.util.TestConstants.DEVICE_TOKEN;
import static com.hertz.digital.hertzrac.util.TestConstants.HTTP_DELETE_METHOD;
import static com.hertz.digital.hertzrac.util.TestConstants.HTTP_GET_METHOD;
import static com.hertz.digital.hertzrac.util.TestConstants.HTTP_PATCH_METHOD;
import static com.hertz.digital.hertzrac.util.TestConstants.HTTP_POST_METHOD;
import static com.hertz.digital.hertzrac.util.TestConstants.LOCALE;
import static com.hertz.digital.hertzrac.util.TestConstants.TEST_BRAND_VAL;
import static com.hertz.digital.hertzrac.util.TestConstants.TEST_CODE_VAL;
import static com.hertz.digital.hertzrac.util.TestConstants.TEST_CORRELATION_ID_VAL;
import static com.hertz.digital.hertzrac.util.TestConstants.TEST_DEVICE_TOKEN_VAL;
import static com.hertz.digital.hertzrac.util.TestConstants.TEST_LOCAL_VAL;
import static org.mockito.MockitoAnnotations.initMocks;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;


import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.hertz.digital.hertzrac.gateway.filter.CorrelationFilter;
import com.hertz.digital.hertzrac.gateway.model.Token;
import com.hertz.digital.hertzrac.gateway.util.Constants;
import com.hertz.digital.hertzrac.gateway.util.JsonUtil;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.http.ServletInputStreamWrapper;

/**
 * This class is used to test the ZuulApiGatewayApplication and filters
 * 
 * @author vijay.bq.kumar
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, value = { "spring.profiles.active=test" })
@TestPropertySource(locations = { "classpath:application-test.properties", "classpath:bootstrap-test.properties" })
public class ZuulApiGatewayApplicationTest extends Assert {

	private CorrelationFilter filter;

	@Value("${local.portno}")
	private int portNo;

	@Value("${local.server.host}")
	private String hostName;

	@Value("${service.prefix.path}")
	private String servicePrefixPath;

	@Value("${endpoint.get.url}")
	private String endPointGetUrl;

	@Value("${endpoint.post.url}")
	private String endPointPostUrl;

	@Value("${endpoint.patch.url}")
	private String endPointPatchUrl;

	@Value("${endpoint.delete.url}")
	private String endPointDeleteUrl;
	
	@Value("${local.server.port}")
	private int portNumber;

	private String getBaseUrl() {
		return "http://" + hostName + ":" + portNo;
	}
	
	@Before
	public void setup() {
		initMocks(this);
		this.filter = new CorrelationFilter();
		
		ReflectionTestUtils.setField(this.filter, "secretKey", "7277fbbbf9808dff9106d1c0093a010f6db7639321988fdb9bb1ebb38b67a28b");
		ReflectionTestUtils.setField(this.filter, "token", getToken());
		
		RequestContext ctx = RequestContext.getCurrentContext();
		ctx.clear();
		ctx.setRequest(new MockHttpServletRequest());		
	}
	
	private Token getToken() {
		Token token = new Token();
		token.setAnonymousId("anonymousId");
		token.setAnonymousPassword("anonymousPassword");
		token.setAuthenticatedId("authenticatedId");
		token.setAuthenticatedPassword("authenticatedPassword");
		return token;
	}

	/**
	 * This method is used to test if the correlation id is not exist in the
	 * HTTP GET request then new correlation is generated and send back in
	 * response.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetRequestWithOutCorrelationId() throws Exception {
		RequestContext ctx = RequestContext.getCurrentContext();
		setMockRequest(ctx, HTTP_GET_METHOD, false);
		
		this.filter.run();

		Map<String, List<String>> queryParamMap = ctx.getRequestQueryParams();
		String correlationIdKey = null;
		String correlationIdValue = null;

		for (Map.Entry<String, List<String>> entry : queryParamMap.entrySet()) {
			if (entry.getKey().equalsIgnoreCase(CORRELATION_ID)) {
				correlationIdKey = entry.getKey();
				correlationIdValue = entry.getValue().get(0);
				break;
			}
		}

		assertNotNull(correlationIdKey);
		if (correlationIdKey != null) {
			assertFalse(correlationIdKey.isEmpty());
			assertTrue(correlationIdValue.length() > 0);
		}

	}

	/**
	 * This method is used to test if the correlation id is exist in the HTTP
	 * GET request then same correlation send back in response and new
	 * correlation id is not created.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetRequestWithCorrelationId() throws Exception {
		RequestContext ctx = RequestContext.getCurrentContext();
		setMockRequest(ctx, HTTP_GET_METHOD, true);
		this.filter.run();

		Map<String, List<String>> queryParamMap = ctx.getRequestQueryParams();
		String correlationIdKey = null;
		String correlationIdValue = null;

		for (Map.Entry<String, List<String>> entry : queryParamMap.entrySet()) {
			if (entry.getKey().equalsIgnoreCase(CORRELATION_ID)) {
				correlationIdKey = entry.getKey();
				correlationIdValue = entry.getValue().get(0);
				break;
			}
		}

		assertNotNull(correlationIdKey);
		if (correlationIdKey != null) {
			assertFalse(correlationIdKey.isEmpty());
			assertTrue(correlationIdValue.length() > 0);
			assertEquals(correlationIdValue, TEST_CORRELATION_ID_VAL);
		}

	}

	/**
	 * This method is used to test if the correlation id is not exist in the
	 * HTTP POST request then new correlation is generated and send back in
	 * response.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testPostRequestWithoutCorrelationId() throws Exception {
		RequestContext ctx = RequestContext.getCurrentContext();
		setMockRequest(ctx, HTTP_POST_METHOD, false);
		this.filter.run();

		HttpServletRequest req = ctx.getRequest();

		// Method to deserialize JSON content as tree
		JsonNode jsonRootNode = JsonUtil.readJson(req.getInputStream());
		String correlationId = jsonRootNode.path(CORRELATION_ID).textValue();

		assertFalse(correlationId.isEmpty());
		assertTrue(correlationId.length() > 0);

	}

	/**
	 * This method is used to test if the correlation id is exist in the HTTP
	 * POST request then same correlation send back in response and new
	 * correlation id is not created.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testPostRequestWithCorrelationId() throws Exception {
		RequestContext ctx = RequestContext.getCurrentContext();
		setMockRequest(ctx, HTTP_POST_METHOD, true);
		Object obj = this.filter.run();

		assertNull(obj);

	}

	/**
	 * This method is used to test if the correlation id is not exist in the
	 * HTTP PATCH request then new correlation is generated and send back in
	 * response.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testPatchRequestWithoutCorrelationId() throws Exception {
		RequestContext ctx = RequestContext.getCurrentContext();
		setMockRequest(ctx, HTTP_PATCH_METHOD, false);
		this.filter.run();

		HttpServletRequest req = ctx.getRequest();

		// Method to deserialize JSON content as tree
		JsonNode jsonRootNode = JsonUtil.readJson(req.getInputStream());
		String correlationId = jsonRootNode.path(CORRELATION_ID).textValue();

		assertFalse(correlationId.isEmpty());
		assertTrue(correlationId.length() > 0);

	}

	/**
	 * This method is used to test if the correlation id is exist in the HTTP
	 * PATCH request then same correlation send back in response and new
	 * correlation id is not created.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testPatchRequestWithCorrelationId() throws Exception {
		RequestContext ctx = RequestContext.getCurrentContext();
		setMockRequest(ctx, HTTP_PATCH_METHOD, true);
		Object obj = this.filter.run();

		assertNull(obj);

	}

	/**
	 * This method is used to test if the correlation id is not exist in the
	 * HTTP DELETE request then new correlation is generated and send back in
	 * response.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testDeleteRequestWithoutCorrelationId() throws Exception {
		RequestContext ctx = RequestContext.getCurrentContext();
		setMockRequest(ctx, HTTP_DELETE_METHOD, false);
		this.filter.run();

		Map<String, List<String>> queryParamMap = ctx.getRequestQueryParams();
		String correlationIdKey = null;
		String correlationIdValue = null;

		for (Map.Entry<String, List<String>> entry : queryParamMap.entrySet()) {
			if (entry.getKey().equalsIgnoreCase(CORRELATION_ID)) {
				correlationIdKey = entry.getKey();
				correlationIdValue = entry.getValue().get(0);
				break;
			}
		}

		assertNotNull(correlationIdKey);
		if (correlationIdKey != null) {
			assertFalse(correlationIdKey.isEmpty());
			assertTrue(correlationIdValue.length() > 0);
		}
	}

	/**
	 * This method test the correlation id already exist then its not created
	 * new Correlation id and send back same as in response of HTTP DELETE
	 * request
	 * 
	 * @throws Exception
	 */
	@Test
	public void testDeleteRequestWithCorrelationId() throws Exception {
		RequestContext ctx = RequestContext.getCurrentContext();
		setMockRequest(ctx, HTTP_DELETE_METHOD, true);
		Object obj = this.filter.run();

		assertNull(obj);
	}

	/**
	 * This method is used to set mock request in request context
	 * 
	 * @param ctx
	 * @param httpMethod
	 * @param isCorrelationId
	 * @throws IOException
	 */
	private void setMockRequest(RequestContext ctx, String httpMethod, boolean isCorrelationId) throws IOException {
		HttpServletRequest request = Mockito.mock(ctx.getRequest().getClass());
		String encryptedToken ="eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiZGlyIn0..zEyf6L1LYIoO_5UH.wEaeL49ZfGDJkHDKSX76B2rqJZBuvWXkyx03t5Le2sn2vqziGwkf_kSBMb4DfXUl2F-t1d6GVWeeEfzvLvfgPpWFtZTR7ErxFjVfxT_o8NgiM7Z6cXLmnDLJ_fSOd27vSj7i_jXW4Ejg3Yl4YPavcnfq12rJ3CyKItVZG6nU6q3RoFtBAy6fN-QzhAVqCuYp6FHn4SFpsl0a_v24TvYRIjtoYjLK4GHZjwRIipaJzGgPS8_sYOEzs-8gA0qUCgs_PahlH9adlXiSj4h87iAG78qhNqLn49OSrr8K77ZtC4r6pdtrmiJzjif8smxjma45OM0SbPf0SDEF08_jM4HrVT0luMmIooH4uzn2_s1q2AaE_63J9P8obm0RCGOg8Bf0IAONg4VwAtBKw3HO99pRX-t58dJNZ5CzYAzubAJQ4pUb7JF0I5wUtbknyisqvgdu84OSAPbkU4zHTU1_-KcHnNLA-RfhmCq7FFjno3yCfmxKNWLgYsF4wtLYU6QK7fmmdsE2HBpOGsMgJ-8FNGfKTmIafi9ujMObl9IKUfqXMxqlzqdp8pacv7Ly323pz57IPanzuCRSSepTVH4K5vpSTskHR2ELIym76bAKeIfTxcIGztcEpk410gpJmi03fLTOC-1WRBS_qeJX7WDT13qR7LnZF6IKuwmuGk4-ycSExXlzlh_N2vwXF1SH_XVRUigoG9wvWX7E2YiGhLobzHEk.rsU318mODk_J7PeYgMkriQ";
		Mockito.when(request.getHeader("Authorization"))
		.thenReturn("Bearer " + encryptedToken);
		Mockito.when(request.getContentType())
		.thenReturn("application/json");
		Mockito.when(request.getRequestURI())
		.thenReturn(servicePrefixPath + endPointGetUrl);

		if (HTTP_GET_METHOD.equalsIgnoreCase(httpMethod)) {
			Mockito.when(request.getMethod()).thenReturn(HTTP_GET_METHOD);
			Mockito.when(request.getRequestURL())
					.thenReturn(new StringBuffer(getBaseUrl() + servicePrefixPath + endPointGetUrl));
			if (isCorrelationId) {
				Mockito.when(request.getParameter(CORRELATION_ID)).thenReturn("1234567");
			}
			setQueryParameter(ctx, isCorrelationId);
			ctx.setRequest(request);
		} else {
			Mockito.when(request.getMethod()).thenReturn(httpMethod);
			if (HTTP_POST_METHOD.equalsIgnoreCase(httpMethod)) {
				Mockito.when(request.getRequestURL())
						.thenReturn(new StringBuffer(getBaseUrl() + servicePrefixPath + endPointPostUrl));
			} else if (HTTP_PATCH_METHOD.equalsIgnoreCase(httpMethod)) {
				Mockito.when(request.getRequestURL())
						.thenReturn(new StringBuffer(getBaseUrl() + servicePrefixPath + endPointPatchUrl));
			} else if (HTTP_DELETE_METHOD.equalsIgnoreCase(httpMethod)) {
				Mockito.when(request.getRequestURL())
						.thenReturn(new StringBuffer(getBaseUrl() + servicePrefixPath + endPointDeleteUrl));
			}
			ServletInputStream inputStream = getInputStream(isCorrelationId);
			Mockito.when(request.getInputStream()).thenReturn(inputStream);

			ctx.setRequest(request);
		}
	}

	/**
	 * This method is used to set query parameter in request context
	 * 
	 * @param ctx
	 * @param isCorrelationId
	 */

	private void setQueryParameter(RequestContext ctx, boolean isCorrelationId) {
		Map<String, List<String>> queryParamMap = new HashMap<>();
		List<String> deviceTokenValue = new ArrayList<>();
		deviceTokenValue.add(TEST_DEVICE_TOKEN_VAL);
		queryParamMap.put(DEVICE_TOKEN, deviceTokenValue);
		List<String> brandValues = new ArrayList<>();
		brandValues.add(TEST_BRAND_VAL);
		queryParamMap.put(BRAND, brandValues);
		List<String> localValues = new ArrayList<>();
		localValues.add(TEST_LOCAL_VAL);
		queryParamMap.put(LOCALE, localValues);
		List<String> codeValues = new ArrayList<>();
		codeValues.add(TEST_CODE_VAL);
		queryParamMap.put(CODE, codeValues);

		if (isCorrelationId) {
			List<String> correlationIdValues = new ArrayList<>();
			correlationIdValues.add(TEST_CORRELATION_ID_VAL);
			queryParamMap.put(CORRELATION_ID, correlationIdValues);

		}
		ctx.setRequestQueryParams(queryParamMap);

	}

	/**
	 * This method is used to convert string to inputstream
	 * 
	 * @param isCorrelationId
	 * @return
	 */
	private ServletInputStream getInputStream(boolean isCorrelationId) {
		String jsonRequest;
		if (isCorrelationId) {
			jsonRequest = "{\"client\":{\"deviceToken\":\"ksdfkjdflkjfd\"},\"errorId\":\"200\",\"locale\":\"enus\",\"brand\":\"Hertz\",\"correlationId\":\"1234567\"}";
		} else {
			jsonRequest = "{\"client\":{\"deviceToken\":\"ksdfkjdflkjfd\"},\"errorId\":\"200\",\"locale\":\"enus\",\"brand\":\"Hertz\"}";
		}
		return new ServletInputStreamWrapper(jsonRequest.getBytes());
	}
	
	@Test
	public void checkError() {
		ResponseEntity<Map> entity = new TestRestTemplate().getForEntity("http://" + hostName + ":" + portNumber +  "/api/test/test", Map.class);
		Map mp = entity.getBody();
		assertNotNull(mp.get(Constants.CORRELATION_ID));
	}
	
	@Test(expected = IllegalArgumentException.class )
	public void testMain() {
		String args[] = null;
		ZuulApiGatewayApplication.main(args);
	}	
	
	
	@Test
	public void testPassword() {
		ResponseEntity<Map> entity = new TestRestTemplate().getForEntity("http://" + hostName + ":" + portNumber +  "/api/token?grant_type=password", Map.class);
	}
	
	@Test
	public void testClient() {
		ResponseEntity<Map> entity = new TestRestTemplate().getForEntity("http://" + hostName + ":" + portNumber +  "/api/token?grant_type=client_credential", Map.class);
	}
	
	
}
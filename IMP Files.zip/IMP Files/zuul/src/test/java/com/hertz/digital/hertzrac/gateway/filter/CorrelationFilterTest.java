package com.hertz.digital.hertzrac.gateway.filter;

import static org.junit.Assert.assertEquals;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.MacSigner;
import org.springframework.test.util.ReflectionTestUtils;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.hertz.digital.hertzrac.gateway.model.Token;
import com.netflix.zuul.context.RequestContext;

public class CorrelationFilterTest {
	
	private CorrelationFilter filter;
	public static final String AUTHORISATION = "Authorization";
	public static final String GRANT_TYPE  ="grant_type";
	public static final String AUTHORIZATION_BASIC  ="Basic ";
	public static final String REFRESH_TOKEN = "refresh_token";
	public static final String AUTHORISATION_PREFIX = "Bearer ";	
	static final MacSigner hmac = new MacSigner("key");
	
	private MockHttpServletRequest request = new MockHttpServletRequest();
	
	private String decryptedToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzY29wZSI6WyJ0cnVzdCJdLCJleHAiOjE0OTY5MDAzMjcsImp0aSI6ImI0MTA4ZDE3LTMxMmMtNGFhNC1hNzdhLTU4OTNiMmJhYjNlYSIsImNsaWVudF9pZCI6Ijhwa2dkb3Npc2NxMjMzMTJjMzVzcGx1bDcyIn0.ePmj6LDedg7Vi_lQhQWDbKtCwLh7IfLJjNwuAlDy9Qkc5Hdb_kQ6yJS1jgMF9wKpP9Zv0JWd7o3olXaDYVc0Wi_EQ4hGHyDRUizGGeGuRfy7LO3JfBRlOZBBsxwM_fU8PJH-vnDR-YmqaBh6Cegxgtrz_9bhUpDy_CFq44dv3SbSwd_5xHq-OVw5KUPygYf2GxJXGshsSFef5DxbxFJfWXUBO7ahdrOOraTRG9eJgNQAnQnEwFP2vJv1cNF7dVceQj9XiFp4uQtk3IGEeM93flqy6RlU1t_Ki6tsiyOOCUDtL5-8lAAyukUzwogrs5sQmTcHnygUfWPc_dCyro_VWw";
	private String decryptedRefreshToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJyb2IubWF0aGV3Iiwic2NvcGUiOlsibG9nZ2VkIl0sImF0aSI6ImE0ZTUzNjVmLWE1NTUtNGJlNS05OGRiLTM1YWFlNTllNDM5YSIsImV4cCI6MTQ5Njk5MTUwNywiYXV0aG9yaXRpZXMiOlsiUk9MRV9NWUFQUFVTRVJTIiwiUk9MRV9BRE1JTklTVFJBVE9SUyJdLCJqdGkiOiI5NmY4NmFlYi1iNjZjLTQzMWEtYTJmNC1kMWIxNjUwOWVkMmIiLCJjbGllbnRfaWQiOiI0ZjM2NmxmajNodDJ0YTAwMWE0ZjY3Z2E4NCJ9.ZAjUGg2tbFD4_5aHA7vabXAZC_tef-c7nDGaTFGVxIWTIgprU3LXEVzHA8IVxTRNxCbc4TRHKg8lk-lwrj7FQU3YKbKT7k0ds-68f6DREUE8_roaamvqoW9ya1iQo9KH9wciTxyIjE7bv44X1cgcuTfu-3Xr8ZOFACjup8bK_Jxf6HwuCmJzSeH6H7jUgXPujDHO3PdUj28bXseDrL8G7exVNLKtUGUiFhbsLTwzkQAh-zTQ9jiZDwacjiAZu1CUhN45VU51d6SSKrZaNXrd8VnwBP2JDim-5f8nJj7X5bc1xftIjqgFew5HbuaV_ILVXVlFmWlESTSuTm2Es90F_A";
	private String basicAuth = "Basic YXV0aGVudGljYXRlZElkOmF1dGhlbnRpY2F0ZWRQYXNzd29yZA==";
	private String basicAuthClient = "Basic YW5vbnltb3VzSWQ6YW5vbnltb3VzUGFzc3dvcmQ=";
	
	Token token = new Token();
	
	@Before
	public void init() {
		this.filter = new CorrelationFilter();
		setTestRequestContext();
		RequestContext ctx = RequestContext.getCurrentContext();
		ctx.clear();
		ReflectionTestUtils.setField(this.filter, "secretKey", "7277fbbbf9808dff9106d1c0093a010f6db7639321988fdb9bb1ebb38b67a28b");
		ReflectionTestUtils.setField(this.filter, "token", getToken());
		ctx.setRequest(this.request);
	}
	
	@Test
	public void testApiCall() {
		RequestContext ctx = RequestContext.getCurrentContext();
		this.request.setRequestURI("/api/test");
		this.request.addHeader(AUTHORISATION,
				"Bearer eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiZGlyIn0..zEyf6L1LYIoO_5UH.wEaeL49ZfGDJkHDKSX76B2rqJZBuvWXkyx03t5Le2sn2vqziGwkf_kSBMb4DfXUl2F-t1d6GVWeeEfzvLvfgPpWFtZTR7ErxFjVfxT_o8NgiM7Z6cXLmnDLJ_fSOd27vSj7i_jXW4Ejg3Yl4YPavcnfq12rJ3CyKItVZG6nU6q3RoFtBAy6fN-QzhAVqCuYp6FHn4SFpsl0a_v24TvYRIjtoYjLK4GHZjwRIipaJzGgPS8_sYOEzs-8gA0qUCgs_PahlH9adlXiSj4h87iAG78qhNqLn49OSrr8K77ZtC4r6pdtrmiJzjif8smxjma45OM0SbPf0SDEF08_jM4HrVT0luMmIooH4uzn2_s1q2AaE_63J9P8obm0RCGOg8Bf0IAONg4VwAtBKw3HO99pRX-t58dJNZ5CzYAzubAJQ4pUb7JF0I5wUtbknyisqvgdu84OSAPbkU4zHTU1_-KcHnNLA-RfhmCq7FFjno3yCfmxKNWLgYsF4wtLYU6QK7fmmdsE2HBpOGsMgJ-8FNGfKTmIafi9ujMObl9IKUfqXMxqlzqdp8pacv7Ly323pz57IPanzuCRSSepTVH4K5vpSTskHR2ELIym76bAKeIfTxcIGztcEpk410gpJmi03fLTOC-1WRBS_qeJX7WDT13qR7LnZF6IKuwmuGk4-ycSExXlzlh_N2vwXF1SH_XVRUigoG9wvWX7E2YiGhLobzHEk.rsU318mODk_J7PeYgMkriQ");
		this.filter.run();		
		assertEquals(decryptedToken, ctx.getZuulRequestHeaders().get("authorization"));
	}
	
	@Test
	public void testPasswordCredential() {
		
		RequestContext ctx = RequestContext.getCurrentContext();
		this.request.setRequestURI("/api/token");
		this.request.setParameter(GRANT_TYPE, "password");
		this.filter.run();			
		assertEquals(basicAuth, ctx.getZuulRequestHeaders().get("authorization"));
	}
	
	@Test
	public void testClientCredential() {		
		RequestContext ctx = RequestContext.getCurrentContext();
		this.request.setRequestURI("/api/token");
		this.request.setParameter(GRANT_TYPE, "client_credentials");
		this.filter.run();			
		assertEquals(basicAuthClient, ctx.getZuulRequestHeaders().get("authorization"));
	}
	
	@Test(expected = BadCredentialsException.class )
	public void testClientCredentialException() {		
		RequestContext ctx = RequestContext.getCurrentContext();
		ReflectionTestUtils.setField(this.filter, "disable", "false");		
		this.request.setRequestURI("/api/token");
		this.request.setParameter(GRANT_TYPE, "client_credentials");
		this.filter.run();			
		assertEquals(basicAuthClient, ctx.getZuulRequestHeaders().get("authorization"));
	}
	
	@Test
	public void testClientCredentialOpaque() throws Exception{		
		RequestContext ctx = RequestContext.getCurrentContext();
		ReflectionTestUtils.setField(this.filter, "disable", "false");
		
		String claim = "{\"iss\":\"joe\",\r\n" + " \"exp\":1300819380,\r\n" + " \"app_id\":\"FED\",\r\n"
				+ " \"created_time\":" + String.valueOf(Instant.now().getEpochSecond()) + ",\r\n"
				+ " \"http://example.com/is_root\":true}";
		String opaqueToken = JwtHelper.encode(claim, hmac).getEncoded();
		
		this.request.addHeader(AUTHORISATION, AUTHORISATION_PREFIX + opaqueToken);		
		this.request.setRequestURI("/api/token");
		this.request.setParameter(GRANT_TYPE, "client_credentials");
		List list = new ArrayList();
		list.add("FED");
		token.setAppName(list);
		token.setTimeLag("30");
		this.filter.run();			
		assertEquals(basicAuthClient, ctx.getZuulRequestHeaders().get("authorization"));
	}
	
	@Test(expected = BadCredentialsException.class )
	public void testClientCredentialOpaqueFail() {		
		RequestContext ctx = RequestContext.getCurrentContext();
		ReflectionTestUtils.setField(this.filter, "disable", "false");
		this.request.addHeader(AUTHORISATION, decryptedToken);		
		this.request.setRequestURI("/api/token");
		this.request.setParameter(GRANT_TYPE, "client_credentials");
		this.filter.run();			
		assertEquals(basicAuthClient, ctx.getZuulRequestHeaders().get("authorization"));
	}
	
	@Test(expected = BadCredentialsException.class )
	public void testRefreshTokenException() {		
		this.request.setRequestURI("/api/token");
		this.request.setParameter(GRANT_TYPE, REFRESH_TOKEN);
		this.request.setParameter(REFRESH_TOKEN, "sdssadas");
		this.filter.run();		
	}
	
	@Test
	public void testRefreshToken() {		
		RequestContext ctx = RequestContext.getCurrentContext();
		this.request.setRequestURI("/api/token");
		this.request.setParameter(GRANT_TYPE, REFRESH_TOKEN);
		this.request.setParameter(REFRESH_TOKEN, "eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiZGlyIn0..wMRVz2-5aJYwRxDu.RrFgelZXUyZqgWEdqgmWLioHubytYM3Cz9QzPVaZOQJuGF-UCvBQ5F0P9VarchaSZuxhipJxA1RcHjF7HPsEqIEiOWPUn781lktj_H1eYXVTLKLjV7fnRNcMSppsTTX3nx0hcVAjbhgAiKACZsl4x_US6aB3_97szZPv4cWZzTA0RBjRZTNHnCpTBIzWupBsouw113wGJ60_AbFu9WjTK7tYZ4N4G5MVrJQCudalN_s_TAoxtQajgoL-F5qbfIepcTrJMnD5GkBDzVlKFphaJsug9J3kDus8lQJteEc3rSvsseqxKQoEGYMFFHrUqF-m1zeXdHxOhNOO_86AzKej-ZiO_9OIof_HkKa4-gzOK3Lay4Z8CJYNUmScA_emxqoeBgpgvC6l257uAlZZ2le-otUn65NFirGkrTIWIvuxUAifJ1b7OxRuahGAi-WgihLTMNFJVNbVQCmsoivPf5jrGGGDeMH6i9NYHikMPzn_aYvaafdPEGIn28UBd27b-iResb0Z7ECeTi70xbZDdrs3c0Rqfkd67ViVnXWN27v3yX-O1ThLNNlM2V2OtGdfbRhtTtu-eJ_VczOjID9emAVG1ayZ34avzto06cC4189oaia29ZrzEsS5SkC00fQzmk-QR_IO_9Kb-J4toV70H2ZCApkavp7im5LvkXjKXPYqsOaegpkQHj4oEeTJFsrciiU0ZFWpdh5FOkfZup4wKFSD6s5wUusC8vsUZVH_qyA1kcflhhfxULEX4tmm7j_D-0zoXvzn_to6TshISCXRbedttxrrVLixOYOXIm1Wb15trV7XJ2jSetmUMape_OpnwmgE_XhB37I6H1Q2qe8xV4WgekuCrZ2PHBWFEHoJ-oelY6vYDvvbJX6-j9_sMmgRX00A0fKjgHoRF-PW8LONB2oNrsRHsgLqCdwLoO5C87ZfYW29z75VNVd8tQ.85ZTOPBd5anNoWhtwxC4ZQ");
		this.filter.run();		
		assertEquals(basicAuth, ctx.getZuulRequestHeaders().get("authorization"));
		assertEquals(decryptedRefreshToken, ctx.getRequestQueryParams().get(REFRESH_TOKEN).get(0));
	}
	
	
	private void setTestRequestContext() {
		RequestContext context = new RequestContext();
		RequestContext.testSetCurrentContext(context);

	}
	
	private Token getToken() {		
		token.setAnonymousId("anonymousId");
		token.setAnonymousPassword("anonymousPassword");
		token.setAuthenticatedId("authenticatedId");
		token.setAuthenticatedPassword("authenticatedPassword");
		return token;
	}	
	

}

package com.hertz.digital.hertzrac.gateway.filter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hertz.digital.hertzrac.gateway.exception.CorrelationException;
import com.hertz.digital.hertzrac.gateway.filter.ExceptionFilter;
import com.hertz.digital.hertzrac.gateway.util.Constants;
import com.netflix.zuul.context.RequestContext;


public class ExceptionErrorFilterTest {
	
	private static final String ERROR ="mockerror";
	
	@Before
	public void setTestRequestcontext() {
		RequestContext context = new RequestContext();
		RequestContext.testSetCurrentContext(context);
	}

	@After
	public void reset() {
		RequestContext.getCurrentContext().clear();
	}
	
	@Test
	public void internalError() throws IOException {
		ExceptionFilter filter = createErrorFilter(new MockHttpServletRequest());
		assertTrue("shouldFilter returned false", filter.shouldFilter());
		filter.run();		
		ObjectMapper mapper = new ObjectMapper();
		Map map = mapper.readValue(RequestContext.getCurrentContext().getResponseBody(), Map.class);
		assertNotNull(map.get(Constants.CORRELATION_ID));
	}
	
	
	private ExceptionFilter createErrorFilter(HttpServletRequest request) {
		RequestContext context = new RequestContext();
		context.setRequest(request);
		context.setResponse(new MockHttpServletResponse());
		context.set("error.status_code", HttpStatus.NOT_FOUND.value());
		context.set("error.exception", new CorrelationException(ERROR, "12345"));
		context.set("error.message", "Mock Error");
		RequestContext.testSetCurrentContext(context);
		return new ExceptionFilter();
	}
	
	@Test
	public void throwableError() throws IOException {
		ExceptionFilter filter = createThrowableError(new MockHttpServletRequest());
		assertTrue("shouldFilter returned false", filter.shouldFilter());
		filter.run();		
		ObjectMapper mapper = new ObjectMapper();
		Map map = mapper.readValue(RequestContext.getCurrentContext().getResponseBody(), Map.class);
		assertNotNull(map.get(Constants.CORRELATION_ID));
	}
	
	private ExceptionFilter createThrowableError(HttpServletRequest request) {
		RequestContext context = new RequestContext();
		context.setRequest(request);
		context.setResponse(new MockHttpServletResponse());
		context.setThrowable(new Throwable());
		CorrelationException exception = new CorrelationException(ERROR);
		exception.setCorrelationId("1234");
		context.set("error.exception", new CorrelationException(ERROR, exception.getCorrelationId()));
		RequestContext.testSetCurrentContext(context);
		return new ExceptionFilter();		
	}


}

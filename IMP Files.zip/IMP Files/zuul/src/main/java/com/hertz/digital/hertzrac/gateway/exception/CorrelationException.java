package com.hertz.digital.hertzrac.gateway.exception;

/**
 * Exception class which is occurs while setting the correlation id
 * into request
 * 
 * @author vijay.bq.kumar
 *
 */
public class CorrelationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private String correlationId;
	
	/*
	 * 
	 */
	public CorrelationException(String message) {
		super(message);
	}

	/**
	 * set the correlation id
	 * @param message
	 * @param correlationId
	 */
	public CorrelationException(String message, String correlationId) {
		super(message);
		this.correlationId = correlationId;
	}

	/**
	 * @return the correlationId
	 */
	public String getCorrelationId() {
		return correlationId;
	}

	/**
	 * @param correlationId
	 *            the correlationId to set
	 */
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	
}

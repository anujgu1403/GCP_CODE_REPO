package com.hertz.digital.hertzrac.gateway.model;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * 
 * Token configuration details 
 *
 */

@ConfigurationProperties(prefix = "token")
@Component
public class Token {	
	
	private String authenticatedId;
	private String authenticatedPassword;
	private String anonymousId;
	private String anonymousPassword;
	private String timeLag;	
	private List<String> tokenAttributes;
	private List<String> appName;
	
	public String getAuthenticatedId() {
		return authenticatedId;
	}
	public void setAuthenticatedId(String authenticatedId) {
		this.authenticatedId = authenticatedId;
	}
	
	public String getAuthenticatedPassword() {
		return authenticatedPassword;
	}
	
	public void setAuthenticatedPassword(String authenticatedPassword) {
		this.authenticatedPassword = authenticatedPassword;
	}
	
	public String getAnonymousId() {
		return anonymousId;
	}
	
	public void setAnonymousId(String anonymousId) {
		this.anonymousId = anonymousId;
	}
	
	public String getAnonymousPassword() {
		return anonymousPassword;
	}
	
	public void setAnonymousPassword(String anonymousPassword) {
		this.anonymousPassword = anonymousPassword;
	}
	
	public String getTimeLag() {
		return timeLag;
	}
	
	public void setTimeLag(String timeLag) {
		this.timeLag = timeLag;
	}
	
	public List<String> getTokenAttributes() {
		return tokenAttributes;
	}
	
	public void setTokenAttributes(List<String> tokenAttributes) {
		this.tokenAttributes = tokenAttributes;
	}
	
	public List<String> getAppName() {
		return appName;
	}
	
	public void setAppName(List<String> appName) {
		this.appName = appName;
	}	
	

}

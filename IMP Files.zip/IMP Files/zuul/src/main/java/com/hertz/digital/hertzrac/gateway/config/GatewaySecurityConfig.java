package com.hertz.digital.hertzrac.gateway.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationManager;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationProcessingFilter;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.hertz.digital.hertzrac.gateway.filter.CustomAuthenticationFilter;
import com.hertz.digital.hertzrac.gateway.model.Unauthenticated;

@Configuration
@EnableWebSecurity
public class GatewaySecurityConfig extends WebSecurityConfigurerAdapter {
    
    @Value("${security.oauth2.resource.jwt.key-value}")
    private String verifierKey;
    
    @Value("${secretKey.key}")
    private String secretKey;
    
    @Autowired
	private Unauthenticated unauthenticated;

    
    @Bean
	@Primary
    public DefaultTokenServices defaultTokenServices() {
        final DefaultTokenServices defaultTokenServices = new DefaultTokenServices();
        defaultTokenServices.setTokenStore(tokenStore());        
        return defaultTokenServices;
    } 
    
    @Bean
    public JwtTokenStore tokenStore() {
        return new JwtTokenStore(jwtAccessTokenConverter());
    }
	
	@Bean
	public JwtAccessTokenConverter jwtAccessTokenConverter() {
		JwtAccessTokenConverter converter = new JwtAccessTokenConverter();		
		converter.setVerifierKey(verifierKey);
		return converter;
	}
	
	protected OAuth2AuthenticationProcessingFilter jwtTokenAuthenticationFilter() throws Exception {        
        OAuth2AuthenticationProcessingFilter filter 
            = new OAuth2AuthenticationProcessingFilter();
        OAuth2AuthenticationManager authenticationManager = new OAuth2AuthenticationManager();
        authenticationManager.setTokenServices(defaultTokenServices());
        filter.setAuthenticationManager(authenticationManager);
        return filter;
    }
	
	protected CustomAuthenticationFilter customAuthenticationFilter() throws Exception {
		CustomAuthenticationFilter filter = new CustomAuthenticationFilter();
		filter.setKey(secretKey);
		return filter;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers(unauthenticated.getPermit().toArray(new String[unauthenticated.getPermit().size()])).permitAll()
			.and().authorizeRequests().antMatchers("/api/mockerror-by-service/**").hasRole("ADMINISTRATORS")
			.and().authorizeRequests().antMatchers("/api/loadLocationData/**").hasAuthority("infact")
			.and().authorizeRequests().antMatchers("/api/customer-by-service/**").authenticated()
			.and().authorizeRequests().antMatchers("/api/cdpService/**").authenticated()
			.and().cors()
			.and().csrf().disable()
			.addFilterBefore(jwtTokenAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
			.addFilterBefore(customAuthenticationFilter(), OAuth2AuthenticationProcessingFilter.class);
	}

}

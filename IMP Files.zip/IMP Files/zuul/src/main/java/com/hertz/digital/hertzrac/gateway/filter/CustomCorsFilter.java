package com.hertz.digital.hertzrac.gateway.filter;

import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;


/**
 * 
 * @author nirmal.vadi
 *
 */
public class CustomCorsFilter extends CorsFilter {
	
	/**
	 * This method is used to add custom CORS processor
	 * @param configSource
	 */
	public CustomCorsFilter(CorsConfigurationSource configSource) {
		super(configSource);
		setCorsProcessor(new CustomDefaultCorsProcessor());
	}

}

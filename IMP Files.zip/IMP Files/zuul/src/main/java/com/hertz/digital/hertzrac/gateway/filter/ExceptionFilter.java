package com.hertz.digital.hertzrac.gateway.filter;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ReflectionUtils;

import com.hertz.digital.hertzrac.gateway.exception.ExceptionEnum;
import com.hertz.digital.hertzrac.gateway.util.CorrelationProcessorUtil;
import com.hertz.digital.hertzrac.gateway.util.ErrorUtil;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

public class ExceptionFilter extends ZuulFilter {

	private static Logger logger = LoggerFactory.getLogger(ExceptionFilter.class);
	private static final String ERROR_STATUS_KEY = "error.status_code";
	

	@Override
	public boolean shouldFilter() {
		RequestContext ctx = RequestContext.getCurrentContext();
		return ctx.getThrowable() != null || ctx.containsKey(ERROR_STATUS_KEY);
	}

	@Override
	public Object run() {
		try {
			RequestContext ctx = RequestContext.getCurrentContext();
			if (ctx.containsKey(ERROR_STATUS_KEY)) {
				int statusCode = (Integer) ctx.get(ERROR_STATUS_KEY);
				logger.error(String.format("### Request %s request to %s failed with error code %s",
						ctx.getRequest().getMethod(), ctx.getRequest().getRequestURL().toString(), statusCode));
				String message = "";
				if (ctx.containsKey("error.exception")) {					
					Object e = ctx.get("error.exception");
					message =  e.toString();
					logger.error("Error exception "  + e.toString());
				}

				if (ctx.containsKey("error.message")) {
					message = (String) ctx.get("error.message");
					logger.error("Error message " + message);

				}
				// Remove error code to prevent further error handling in follow
				// up filters
				ctx.remove(ERROR_STATUS_KEY);
				ExceptionEnum enumValue = ExceptionEnum.valueOf("INTERNAL_ERROR");
				ErrorUtil.setErrorResponse(ctx, enumValue.getErrorCode(), enumValue.getErrorMessage(),
						message, CorrelationProcessorUtil.getCorrelationId(ctx));
				ctx.setResponseStatusCode(enumValue.getResponseCode());
				ctx.getResponse().setContentType("application/json;charset=UTF-8");
				ctx.setSendZuulResponse(false);
			} else if (ctx.getThrowable() != null) {
				logger.error(String.format("### Request %s request to %s", ctx.getRequest().getMethod(),
						ctx.getRequest().getRequestURL().toString()));
				ExceptionEnum enumValue = ExceptionEnum.valueOf("INTERNAL_ERROR");
				String title = enumValue.getErrorMessage();
				if(null !=  ctx.getThrowable().getCause()) {
					title = ctx.getThrowable().getCause().toString();
				}
				ErrorUtil.setErrorResponse(ctx, enumValue.getErrorCode(), title,
						"Internal error occured.", CorrelationProcessorUtil.getCorrelationId(ctx));
				ctx.setResponseStatusCode(enumValue.getResponseCode());
				ctx.getResponse().setContentType("application/json;charset=UTF-8");
			}
		} catch (Exception ex) {
			logger.error("Exception filtering in custom error filter", ex);
			ReflectionUtils.rethrowRuntimeException(ex);
		}
		return null;
	}

	@Override
	public String filterType() {
		return "post";
	}

	@Override
	public int filterOrder() {
		return -1;
	}

	
}

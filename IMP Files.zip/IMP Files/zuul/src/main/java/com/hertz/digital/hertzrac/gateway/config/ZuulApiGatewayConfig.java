package com.hertz.digital.hertzrac.gateway.config;

import static com.hertz.digital.hertzrac.gateway.util.Constants.CORRELATION_ID;
import static com.hertz.digital.hertzrac.gateway.util.Constants.DEBUG_NODE;
import static com.hertz.digital.hertzrac.gateway.util.Constants.ERROR;
import static com.hertz.digital.hertzrac.gateway.util.Constants.INVALID_REQUEST;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.web.DefaultErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorAttributes;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hertz.digital.hertzrac.gateway.exception.ExceptionEnum;
import com.hertz.digital.hertzrac.gateway.filter.CorrelationFilter;
import com.hertz.digital.hertzrac.gateway.filter.EncryptFilter;
import com.hertz.digital.hertzrac.gateway.filter.ExceptionFilter;
import com.hertz.digital.hertzrac.gateway.model.ErrorDebug;
import com.hertz.digital.hertzrac.gateway.util.CorrelationProcessorUtil;

/**
 * This class contains all the beans
 * 
 * @author vijay.bq.kumar
 *
 */
@Configuration
public class ZuulApiGatewayConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(ZuulApiGatewayConfig.class);	

	@Bean
	@RefreshScope
	public CorrelationFilter runCorrelationFilter() {
		return new CorrelationFilter();
	}
	
	@Bean
	public EncryptFilter encrypFilter() {
		return new EncryptFilter();
	}

	@Bean
	public ExceptionFilter exceptionFilter() {
		return new ExceptionFilter();
	}
	
	/**
	 * Overrides the default spring error(/error) attribute	response 
	 *
	 */

	@Bean
	public ErrorAttributes errorAttributes() {
		return new DefaultErrorAttributes() {
			@Override
			public Map<String, Object> getErrorAttributes(RequestAttributes requestAttributes,
					boolean includeStackTrace) {
				Map<String, Object> errorAttributes;
				Map<String, Object> orginalErrorAttributes = super.getErrorAttributes(requestAttributes, includeStackTrace);
				try {
					HttpServletRequest request = ((ServletRequestAttributes) requestAttributes).getRequest();
					errorAttributes = new LinkedHashMap<>();
					errorAttributes.put(CORRELATION_ID, CorrelationProcessorUtil.getCorrelationId(request));
					getErrorObject(orginalErrorAttributes, errorAttributes);					
					LOGGER.error("### Exception occured for request {} , method {} and response {} ", request.getRequestURL(), request.getMethod(), errorAttributes);
				} catch (Exception e) {
					errorAttributes = super.getErrorAttributes(requestAttributes, includeStackTrace);
					LOGGER.error("### Exception occured creating error response and exception is {} ", e);
				}
				return errorAttributes;
			}
		};
	}
	
	private ErrorDebug getErrorObject(Map<String, Object> orginalErrorAttributes, Map<String, Object> errorAttributes) {
		ErrorDebug debug = new ErrorDebug();
		ExceptionEnum enumValue = ExceptionEnum.valueOf(INVALID_REQUEST);
		debug.setCode(enumValue.getErrorCode());
		debug.setTitle(enumValue.getErrorMessage());
		debug.setBody((String) orginalErrorAttributes.get(ERROR));
		errorAttributes.put(DEBUG_NODE, debug);
		return debug;		
	}

}

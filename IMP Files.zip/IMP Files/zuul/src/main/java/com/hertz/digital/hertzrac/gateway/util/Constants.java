package com.hertz.digital.hertzrac.gateway.util;

/**
 * This class contains the constants
 * 
 * @author vijay.bq.kumar
 *
 */
public class Constants {
	

	public static final String HTTP_POST_METHOD = "POST";

	public static final String HTTP_PATCH_METHOD = "PATCH";

	public static final String HTTP_GET_METHOD = "GET";

	public static final String HTTP_DELETE_METHOD = "DELETE";

	public static final String PRE_FILTER = "pre";

	public static final String CORRELATION_ID = "correlationId";

	public static final String DEBUG_ATTR_CODE = "code";

	public static final String DEBUG_ATTR_TITLE = "title";

	public static final String DEBUG_ATTR_BODY = "body";

	public static final String DEBUG_NODE = "debug";

	public static final String INVALID_REQUEST = "INVALID_REQUEST";
	
	public static final String ERROR = "error";
	
	private Constants() {
		throw new IllegalAccessError("Utility class");
	}

}

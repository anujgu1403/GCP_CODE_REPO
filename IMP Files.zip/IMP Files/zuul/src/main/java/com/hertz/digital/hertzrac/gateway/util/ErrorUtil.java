package com.hertz.digital.hertzrac.gateway.util;

import static com.hertz.digital.hertzrac.gateway.util.Constants.CORRELATION_ID;
import static com.hertz.digital.hertzrac.gateway.util.Constants.DEBUG_ATTR_BODY;
import static com.hertz.digital.hertzrac.gateway.util.Constants.DEBUG_ATTR_CODE;
import static com.hertz.digital.hertzrac.gateway.util.Constants.DEBUG_ATTR_TITLE;
import static com.hertz.digital.hertzrac.gateway.util.Constants.DEBUG_NODE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.netflix.zuul.context.RequestContext;

/**
 * This class contains the error response
 * 
 * @author vijay.bq.kumar
 *
 */
public class ErrorUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(CorrelationProcessorUtil.class);

	/**
	 * This method is used to set Error in response
	 * 
	 * @param ctx
	 * @param code
	 * @param title
	 * @param messageBody
	 */
	public static void setErrorResponse(RequestContext ctx, final String code, final String title,
			final String messageBody, final String correlationId) {
		// Create JSON root node
		ObjectNode jsonRootNode = getErrorJsonNode(code, title, messageBody, correlationId);
		try {
			// set response into HTTP response
			ctx.setResponseBody(JsonUtil.writeJson(jsonRootNode));
		} catch (JsonProcessingException jsonProcessingException) {
			LOGGER.error("### Exception occur while writing response ", jsonProcessingException);
		}
	}

	public static ObjectNode getErrorJsonNode(final String code, final String title, final String messageBody,
			final String correlationId) {

		ObjectNode jsonRootNode = JsonUtil.createNode();
		// Add a new node for correlation id into JSON tree
		((ObjectNode) jsonRootNode).put(CORRELATION_ID, correlationId);
		// Add Debug json node
		setDebugJsonNode(jsonRootNode, code, title, messageBody);
		return jsonRootNode;
	}

	/**
	 * This method is used to set the debug node in to root
	 * 
	 * @param jsonRootNode
	 * @param code
	 * @param title
	 * @param body
	 */
	public static void setDebugJsonNode(final JsonNode jsonRootNode, final String code, final String title,
			final String messageBody) {

		ObjectNode debugNode = JsonUtil.createNode();
		debugNode.put(DEBUG_ATTR_CODE, code);
		debugNode.put(DEBUG_ATTR_TITLE, title);
		debugNode.put(DEBUG_ATTR_BODY, messageBody);
		((ObjectNode) jsonRootNode).set(DEBUG_NODE, debugNode);

	}
}

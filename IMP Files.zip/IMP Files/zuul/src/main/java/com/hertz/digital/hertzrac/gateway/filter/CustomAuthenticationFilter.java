package com.hertz.digital.hertzrac.gateway.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.oauth2.common.OAuth2AccessToken;

/**
 * Adds a request wrapper for Oauth2 request 
 * 
 */

public class CustomAuthenticationFilter implements Filter {
	
	private String key;	

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;		
		String value = request.getHeader("Authorization");
		if ((null != value && value.toLowerCase().startsWith(OAuth2AccessToken.BEARER_TYPE.toLowerCase()))) {
			HttpServletRequestHeaderWrapper requestWrapper = new HttpServletRequestHeaderWrapper(request, key);
			chain.doFilter(requestWrapper, response);
		} else {
			chain.doFilter(req, response);
		}
	}

	@Override
	public void destroy() {
	}

}

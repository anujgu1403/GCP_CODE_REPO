package com.hertz.digital.hertzrac.gateway.util;

import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * This class is used for marshaling and unmarshaling the JSON
 * 
 * @author vijay.bq.kumar
 *
 */
public class JsonUtil {
	

	private static final Logger LOGGER = LoggerFactory.getLogger(JsonUtil.class);

	private static ObjectMapper objectMapper = new ObjectMapper();
	
	private JsonUtil() {
		throw new IllegalAccessError("Utility class");
	}

	/**
	 * Method to deserialize JSON content as tree expressed using set of
	 * JsonNode instances
	 * 
	 * @param InputStream
	 * @return JsonNode
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	public static JsonNode readJson(InputStream inputStream) throws JsonProcessingException, IOException {
		return objectMapper.readTree(inputStream);		
	}
	
	/**
	 * Method to deserialize JSON content as tree expressed using set of
	 * JsonNode instances
	 * 
	 * @param InputStream
	 * @return JsonNode
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	public static JsonNode readJson(String jsonStr) throws JsonProcessingException, IOException {
		return objectMapper.readTree(jsonStr);		
	}


	/**
	 * This method is used to serialize an object to a String
	 * 
	 * @param Object
	 * @return String
	 * @throws JsonProcessingException
	 */
	public static String writeJson(Object obj) throws JsonProcessingException {
		String json = objectMapper.writeValueAsString(obj);
		LOGGER.info(" JSON is\n {} ", json);
		return json;
	}

	/**
	 * This method is used to create a New Node
	 * @return ObjectNode
	 */
	public static ObjectNode createNode() {
		return objectMapper.createObjectNode();		
	}

}

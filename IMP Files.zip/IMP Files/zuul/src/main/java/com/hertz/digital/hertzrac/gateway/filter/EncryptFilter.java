package com.hertz.digital.hertzrac.gateway.filter;

import static org.apache.commons.codec.binary.Hex.decodeHex;

import java.util.Map;

import javax.crypto.spec.SecretKeySpec;


import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Throwables;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.DirectEncrypter;

/**
 * Post filter
 * Encrypts the access and refresh token 
 * 
 */


public class EncryptFilter extends ZuulFilter {

	@Value("${secretKey.key}")
	private String secretKey;

	private static final ObjectMapper objectMapper = new ObjectMapper();

	@Override
	public boolean shouldFilter() {
		RequestContext context = RequestContext.getCurrentContext();		
		return context.getRequest().getRequestURI().endsWith("/api/token")
				&& context.getRequest().getMethod().toLowerCase().equals("post") && isOk(context)
				&& containsContent(context);
	}

	/**
	 *  
	 *  Marshalls the response
	 *  encrypts the access and refresh token
	 * 
	 */
	@Override
	public Object run() {
		try {
			final RequestContext context = RequestContext.getCurrentContext();
			Map<String, Object> response = null;
			if (context.getResponseBody() != null) {
				response = objectMapper.readValue(context.getResponseBody(), new TypeReference<Map<String, Object>>() {
				});
			} else if (context.getResponseDataStream() != null) {
				response = objectMapper.readValue(context.getResponseDataStream(),
						new TypeReference<Map<String, Object>>() {
						});
			}
			if (response != null) {
				encryptToken(response);
				context.setResponseBody(objectMapper.writeValueAsString(response));
			}

		} catch (final Exception e) {
			Throwables.propagate(e);
		}
		return null;
	}

	protected void encryptToken(Map<String, Object> response) throws Exception {
		encryptJwt("access_token", response);
		encryptJwt("refresh_token", response);
	}

	protected void encryptJwt(String key, Map<String, Object> response) throws Exception {
		Object value = response.get(key);
		if (value instanceof String) {
			response.put(key, encryptToken(response.get(key).toString()));
		}
	}

	@Override
	public String filterType() {
		return "post";
	}

	@Override
	public int filterOrder() {
		return 0;
	}
	
	/**
	 * 
	 * Encrypts the token
	 * 
	 * @param token
	 * @return encrypted token
	 * @throws Exception
	 */

	private String encryptToken(String token) throws Exception {
		byte[] encoded = decodeHex(secretKey.toCharArray());
		JWEObject jweObject = new JWEObject(
				new JWEHeader.Builder(JWEAlgorithm.DIR, EncryptionMethod.A256GCM).contentType("JWT").build(),
				new Payload(token));
		jweObject.encrypt(new DirectEncrypter(new SecretKeySpec(encoded, "AES").getEncoded()));
		return jweObject.serialize();		
	}
	
	/**
	 * 
	 * Checks for successful response
	 * 
	 * @param context
	 * @return
	 */

	private static boolean isOk(final RequestContext context) {
		assert context != null;
		return context.getResponseStatusCode() == 200;
	}
	
	/**
	 * 
	 * Checks response body content
	 * 
	 * @param context
	 * @return
	 */
	private static boolean containsContent(final RequestContext context) {
		assert context != null;
		return context.getResponseDataStream() != null || context.getResponseBody() != null;
	}

}

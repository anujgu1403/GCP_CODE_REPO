package com.hertz.digital.hertzrac.gateway.exception;

/**
 * enum class which contains error codes, messages and response code
 * 
 * @author vijay.bq.kumar
 *
 */
public enum ExceptionEnum {

	INVALID_CORS_REQUEST("GWY-ERR-4031", "Invalid CORS request", 403), INVALID_REQUEST("GWY-ERR-4001",
			"Request is not valid", 400), INTERNAL_ERROR("GWY-ERR-5001", "Internal error occured", 500);
	
	private String errorCode;

	private String errorMessage;

	private int responseCode;	
	
	/**
	 * 
	 * @param errorCode
	 * @param errorMessage
	 * @param responseCode
	 */
	private ExceptionEnum(String errorCode, String errorMessage, int responseCode) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.responseCode = responseCode;
	}

	

	/**
	 * @return the error code
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @return the error message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @return the response code
	 */
	public int getResponseCode() {
		return responseCode;
	}

}

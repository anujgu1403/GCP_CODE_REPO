package com.hertz.digital.hertzrac.gateway.filter;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.zuul.web.ZuulHandlerMapping;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import static com.hertz.digital.hertzrac.gateway.util.Constants.HTTP_GET_METHOD;
import static com.hertz.digital.hertzrac.gateway.util.Constants.HTTP_POST_METHOD;
import static com.hertz.digital.hertzrac.gateway.util.Constants.HTTP_PATCH_METHOD;
import static com.hertz.digital.hertzrac.gateway.util.Constants.HTTP_DELETE_METHOD;

/**
 * This class is used to handle the CORS request
 * 
 * @author nirmal.vadi
 *
 */
@Configuration
public class GatewayCorsFilter {

	private static final Logger LOGGER = LoggerFactory.getLogger(GatewayCorsFilter.class);

	@Autowired
	private ZuulHandlerMapping zuulHandlerMapping;

	public void setZuulHandlerMapping(ZuulHandlerMapping zuulHandlerMapping) {
		this.zuulHandlerMapping = zuulHandlerMapping;
	}

	/**
	 * Create a Corsfilter. Spring DefaultCorsProcessor 
	 * handles the CORS request
	 * 
	 */
	@Bean
	@PostConstruct
	public CustomCorsFilter corsFilter() {
		LOGGER.debug("Inside cors filter");
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		CorsConfiguration config = new CorsConfiguration();
		config.setAllowCredentials(true); // Allows cookies,authentication
		config.addAllowedOrigin("*"); // Allows request from all domain
		config.addAllowedHeader("*"); // Allows all headers
		config.setAllowedMethods(
				Arrays.asList(HTTP_GET_METHOD, HTTP_POST_METHOD, HTTP_DELETE_METHOD, HTTP_PATCH_METHOD));
		source.registerCorsConfiguration("/**", config);
		Map<String, CorsConfiguration> map = new HashMap<>();
		map.put("/**", config);
		zuulHandlerMapping.setCorsConfigurations(map); // Pass the cors
														// configuration to
														// the handler
														// If fails
														// stops the flow
		return new CustomCorsFilter(source);
	}

}

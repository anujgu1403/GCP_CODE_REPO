package com.hertz.digital.hertzrac.gateway.filter;


import static org.apache.commons.codec.binary.Hex.*;
import static com.hertz.digital.hertzrac.gateway.util.Constants.PRE_FILTER;

import java.time.Instant;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hertz.digital.hertzrac.gateway.exception.CorrelationException;
import com.hertz.digital.hertzrac.gateway.model.Token;
import com.hertz.digital.hertzrac.gateway.util.CorrelationProcessorUtil;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.crypto.DirectDecrypter;


/**
 * This class is used read the inputsteam/request parameters and verify if request contains
 * correlation id, if not, then generate a new correlation id and set into
 * HttpServletRequest.
 * 
 * @author vijay.bq.kumar
 *
 */

public class CorrelationFilter extends ZuulFilter {

	private static final Logger LOGGER = LoggerFactory.getLogger(CorrelationFilter.class);
	
	public static final String AUTHORISATION = "Authorization";
	public static final String AUTHORISATION_PREFIX = "Bearer ";
	public static final String AUTHORISATION_OPAQUE = "Opaque ";
	public static final String SKIP_TOKEN = "/api/token";
	public static final String AUTHORIZATION_BASIC  ="Basic ";
	public static final String GRANT_TYPE  ="grant_type";
	public static final String REQUEST_ENTITY_KEY = "requestEntity";
	public static final String REFRESH_TOKEN = "refresh_token";
	
	@Value("${secretKey.key}")
	private String secretKey;
	
	@Value("${opaque.disable}")
	private String disable;
	
	@Autowired
	private Token token;
	
	@Override
	public String filterType() {
		return PRE_FILTER;
	}

	@Override
	public int filterOrder() {
		return 1;
	}

	@Override
	public boolean shouldFilter() {
		return true;
	}

	/**
	 * Appends required attributes to fetch the token since the FED and Mobile will not be sending it out
	 * Checks if the Correlation id exists in HTTP request and if not add a new randomly generated UUID
	 * as a correlation id into request.
	 * 
	 */
	@Override
	public Object run() {
		LOGGER.debug("### Executing run {} ", CorrelationFilter.class.getName());
		RequestContext ctx = RequestContext.getCurrentContext();
		HttpServletRequest request = ctx.getRequest();
		try {
			appendCredentials(ctx);
			LOGGER.info("Request Method is: {} and request URL is: {} ", request.getMethod(),
					request.getRequestURL().toString());

			if (null != request.getContentType() && request.getContentType().equals("application/json")) {
				CorrelationProcessorUtil.setRequestCorrelationId(ctx); // set Correlation id in Request, if not exist
			}
		} catch (CorrelationException e) { // set Error Resposne
			LOGGER.error("### Exception occured running correlation pre filter and exception is {} ", e);
			ReflectionUtils.rethrowRuntimeException(e);
		}
		return null;
	}

	/**
	 * @return
	 * convert to base64 encoding
	 * 
	 */
	private String getCredential(String credentials) {
		byte[] base64CredentialsBytes = Base64.encodeBase64((credentials).getBytes());
		String base64Credentials = new String(base64CredentialsBytes);
		return AUTHORIZATION_BASIC + base64Credentials;
	}
	
	/**
	 * 
	 *  - Validate if token is present for all API calls
	 *  - decrypt token and add it in header for all API calls
	 *  - Append the required parameter to get the token id for password grant, refresh and client credentials
	 *  - For client credentials validate the opaque token
	 * 
	 */

	private void appendCredentials(RequestContext ctx) {
		HttpServletRequest request = ctx.getRequest();
		String header = request.getHeader(AUTHORISATION);
		if (!request.getRequestURI().equals(SKIP_TOKEN)
				&& (StringUtils.isEmpty(header) || !header.startsWith(AUTHORISATION_PREFIX))) { // throw error when Authorisation header is not available
			throw new BadCredentialsException("Could not obtain access token");

		} else if (!request.getRequestURI().equals(SKIP_TOKEN)
				&& (!StringUtils.isEmpty(header) || header.startsWith(AUTHORISATION_PREFIX))) { // token relay the decrypted one. RibbonRoutingFilter will send it across 
			try {
				String encryptedToken = request.getHeader(AUTHORISATION).substring(OAuth2AccessToken.BEARER_TYPE.length()).trim();
				ctx.addZuulRequestHeader(AUTHORISATION, OAuth2AccessToken.BEARER_TYPE + " " + decryptToken(ctx, encryptedToken)); 
			} catch (Exception e) {
				LOGGER.error("### Exception occured while decrypting token ", e);
				throw new BadCredentialsException("Could not decrypt token");
			}

		} else if (request.getRequestURI().equals(SKIP_TOKEN)
				&& ("password".equals(request.getParameter(GRANT_TYPE)))) { // Password grant
			ctx.addZuulRequestHeader(AUTHORISATION,
					getCredential(token.getAuthenticatedId() + ":" + token.getAuthenticatedPassword()));

		} else if (request.getRequestURI().equals(SKIP_TOKEN)
				&& (REFRESH_TOKEN.equals(request.getParameter(GRANT_TYPE)))) { // Refresh token grant
			String refreshToken = request.getParameter(REFRESH_TOKEN);
			try {
				String token = decryptToken(ctx, refreshToken); 
				updateRequestParam(ctx, token);
			} catch (Exception e) {
				LOGGER.error("### Exception occured whule decrypting token ", e);
				throw new BadCredentialsException("Could not decrypt token");
			}
			ctx.addZuulRequestHeader(AUTHORISATION,
					getCredential(token.getAuthenticatedId() + ":" + token.getAuthenticatedPassword()));

		} else if (request.getRequestURI().equals(SKIP_TOKEN)
				&& (("client_credentials".equals(request.getParameter(GRANT_TYPE)))
						&& (null != header && header.startsWith(AUTHORIZATION_BASIC)))) { // Client credentials grant			
			ctx.addZuulRequestHeader(AUTHORISATION, header);
			
		} else if (request.getRequestURI().equals(SKIP_TOKEN)
				&& ("client_credentials".equals(request.getParameter(GRANT_TYPE)))) { // Client credentials grant
			try {
				if (("false".equals(disable)) && !validateToken(header)) {
					throw new BadCredentialsException("Could not validate token");
				}
			} catch (Exception e) {
				LOGGER.error("### Exception occured whule decoding token ", e);
				throw new BadCredentialsException("Could not validate token");
			}
			ctx.addZuulRequestHeader(AUTHORISATION,
					getCredential(token.getAnonymousId() + ":" + token.getAnonymousPassword()));
		}
	}

	/**
	 * 
	 *  Validate if token is sent for anonmoyous user
	 *  Decode and verify the token 	 *  
	 * 
	 */
	
	private boolean validateToken(String header) throws Exception {
		if (StringUtils.isEmpty(header) || !header.startsWith(AUTHORISATION_PREFIX)) {
			throw new BadCredentialsException("Could not obtain access token");
		}
		Jwt tokenDecoded = JwtHelper.decode(header.substring(AUTHORISATION_PREFIX.length(), header.length()));
		Map authInfo = new ObjectMapper().readValue(tokenDecoded.getClaims(), Map.class);
		Object createdTime = authInfo.get("created_time");	
		long diff = 0;
		if (createdTime != null) {
			long currentTime = Instant.now().getEpochSecond();		
			long expTime = (Integer)createdTime;
			diff = currentTime - expTime;
		}	
		
		if (createdTime == null || (!token.getAppName().contains(authInfo.get("app_id")))
				|| !(diff > 0 && diff < Long.parseLong(token.getTimeLag())))
			return false;
		return true;
	}
	
	/**
	 *  Decrypt the token 
	 */
	
	private String  decryptToken(RequestContext ctx, String token) throws Exception {		
		JWEObject jweObject = JWEObject.parse(token);
		byte[] encoded = decodeHex(secretKey.toCharArray());
		jweObject.decrypt(new DirectDecrypter(new SecretKeySpec(encoded, "AES").getEncoded()));		
		return jweObject.getPayload().toString();		
	}
	
	/** 
	 *  Update the param in the zuul context  
	 * 
	 */
	
	private void updateRequestParam(RequestContext ctx, String token) throws Exception {
		List<String> queryParamValues = new LinkedList<>();
		Map<String, List<String>> queryParamMap = ctx.getRequestQueryParams();
		queryParamValues.add(token);
		if (queryParamMap == null) {
			queryParamMap = new HashMap<>();
			queryParamMap.put(REFRESH_TOKEN, queryParamValues);
			ctx.setRequestQueryParams(queryParamMap);
		} else {
			queryParamMap.put(REFRESH_TOKEN, queryParamValues);
		}

	}
	
}

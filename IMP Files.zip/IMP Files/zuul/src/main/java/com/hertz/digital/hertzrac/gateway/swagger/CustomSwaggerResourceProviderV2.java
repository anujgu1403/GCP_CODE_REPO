package com.hertz.digital.hertzrac.gateway.swagger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 
 * Supports Swagger version 2.0. 
 * Consolidate All the microservice swagger urls
 * Takes preference over the InMemorySwaggerResourcesProvider
 *
 */
@Configuration
@EnableSwagger2
@Component
@Primary
@EnableAutoConfiguration
@ConditionalOnProperty(prefix = "swagger", value = "enable")
public class CustomSwaggerResourceProviderV2 implements SwaggerResourcesProvider {	

	@Override
	public List<SwaggerResource> get() {
		List<SwaggerResource> resources = new ArrayList<>();
		resources.add(resource("mock-error-service", "/api/mockerror-by-service/v2/api-docs?group=mock-error-service"));
		resources.add(resource("customer-service", "/api/customer-by-service/v2/api-docs?group=customer-service"));
		resources.add(resource("content-service", "/api/content-by-service/v2/api-docs?group=content-service"));
		resources.add(resource("cdp-service", "/api/cdpService/v2/api-docs?group=cdp-service"));
		resources.add(resource("experience-service", "/api/locationsSearch/v2/api-docs?group=experience-service"));
		resources.add(resource("inr-load-service", "/api/loadLocationData/v2/api-docs?group=inr-load-service"));
		resources.add(resource("quote-service", "/api/vehiclequote/v2/api-docs?group=quote-service"));
		resources.add(resource("reservation-service", "/api/reserve/v2/api-docs?group=reservation-service"));
		resources.add(resource("vehicle-service", "/api/vehicleService/v2/api-docs?group=vehicle-service"));
		resources.add(resource("mashup-service", "/api/mashupService/v2/api-docs?group=mashup-service"));
		resources.add(resource("configuration-service", "/api/configurationService/v2/api-docs?group=configuration-service"));
		resources.add(resource("location-details-service", "/api/locationDetailsService/v2/api-docs?group=location-details-service"));
		resources.add(resource("rate-qualifier-code-service", "/api/rateCodeService/v2/api-docs?group=rate-qualifier-code-service"));
		resources.add(resource("registration-service", "/api/user/v2/api-docs?group=registration-service"));
		resources.add(resource("account-profile-service", "/api/account/v2/api-docs?group=account-profile-service"));
		resources.add(resource("corporate-discount-programe-service", "/api/user/v2/api-docs?group=corporate-discount-programe-service"));
		resources.add(resource("retrievememberid-experiance-service", "/api/retrieve-memberid-experiance/v2/api-docs?group=retrievememberid-experiance-service"));
		Collections.sort(resources);
		return resources;
	}

	private SwaggerResource resource(String swaggerGroup, String baseUrl) {
		SwaggerResource swaggerResource = new SwaggerResource();
		swaggerResource.setName(swaggerGroup);
		swaggerResource.setLocation(baseUrl);
		swaggerResource.setSwaggerVersion("2.0");
		return swaggerResource;
	}

}

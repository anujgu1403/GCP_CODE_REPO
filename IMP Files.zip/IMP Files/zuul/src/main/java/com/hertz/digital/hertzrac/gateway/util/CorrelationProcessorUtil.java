package com.hertz.digital.hertzrac.gateway.util;

import static com.hertz.digital.hertzrac.gateway.util.Constants.CORRELATION_ID;
import static com.hertz.digital.hertzrac.gateway.util.Constants.HTTP_DELETE_METHOD;
import static com.hertz.digital.hertzrac.gateway.util.Constants.HTTP_GET_METHOD;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.hertz.digital.hertzrac.gateway.exception.CorrelationException;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.http.HttpServletRequestWrapper;
import com.netflix.zuul.http.ServletInputStreamWrapper; 

/**
 * This class contains the method related to CorrelationId
 * 
 * @author vijay.bq.kumar
 *
 */
public class CorrelationProcessorUtil {	


	private static final Logger LOGGER = LoggerFactory.getLogger(CorrelationProcessorUtil.class);
	
	private CorrelationProcessorUtil() {
		throw new IllegalAccessError("Utility class");
	}

	/**
	 * This method is used to generate the Correlation Id
	 * 
	 * @return String
	 */
	public static String generateCorrelationId() {
		return UUID.randomUUID().toString();		
	}

	/**
	 * This method is used to create a wrapper of HttpServletRequest for setting
	 * a new request body
	 * 
	 * @param request
	 * @param json
	 * @return HttpServletRequestWrapper
	 */
	public static HttpServletRequestWrapper createRequestWrapper(HttpServletRequest request, String json) {
		return new HttpServletRequestWrapper(request) {
			@Override
			public ServletInputStream getInputStream() throws IOException {
				// convert String into ServletInputStream
				return new ServletInputStreamWrapper(json.getBytes());
			}

			@Override
			public BufferedReader getReader() throws IOException {
				// convert String into ServletInputStream
				return new BufferedReader(new InputStreamReader(getInputStream()));
			}

			@Override
			public int getContentLength() {
				return json.length();

			}

		};
	}

	/**
	 * This method is used to update correlation id in to JSON
	 * 
	 * @param jsonRootNode
	 * @return String
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	public static String updateJsonRequest(JsonNode jsonRootNode, final String correlationId)
			throws JsonProcessingException, IOException {

		// Add a new node for correlation id into JSON tree
		((ObjectNode) jsonRootNode).put(CORRELATION_ID, correlationId);

		// Marshal the request into JSON String
		return JsonUtil.writeJson(jsonRootNode);

	}

	/**
	 * This method is used to set correlation id in to request
	 * 
	 * @param ctx
	 * @throws CorrelationException
	 */
	public static void setRequestCorrelationId(RequestContext ctx) throws CorrelationException {
		HttpServletRequest request = ctx.getRequest();
		String correlationId = null;
		try {
			//  RAC-968 change
			if (HTTP_GET_METHOD.equalsIgnoreCase(request.getMethod()) || HTTP_DELETE_METHOD.equalsIgnoreCase(request.getMethod())) {
				correlationId = request.getParameter(CORRELATION_ID);
				if (StringUtils.isBlank(correlationId)) {
					correlationId = generateCorrelationId();
					LOGGER.info("No correlationId found in request. Generated new correlationId {}", correlationId);

					// get all query parameters from request
					Map<String, List<String>> queryParamMap = ctx.getRequestQueryParams();
					List<String> queryParamValues = new LinkedList<>();
					queryParamValues.add(correlationId);
					if (queryParamMap == null) {
						queryParamMap = new HashMap<>();
						queryParamMap.put(CORRELATION_ID, queryParamValues);
						ctx.setRequestQueryParams(queryParamMap);
					} else {
						queryParamMap.put(CORRELATION_ID, queryParamValues);
					}
				} else {
					LOGGER.info("CorrelationId found in request. {}", correlationId);
				}
			} else {
				// Read the request body
				InputStream inputStream = request.getInputStream();

				// Method to deserialize JSON content as tree
				JsonNode jsonRootNode = JsonUtil.readJson(inputStream);
				correlationId = jsonRootNode.path(CORRELATION_ID).textValue();

				// Checks if CorrelationId is not exists
				if (StringUtils.isBlank(correlationId)) {
					correlationId = generateCorrelationId();
					LOGGER.info("No correlationId found in request. Generated new correlationId {}", correlationId);
					// get updated Json with correlationId
					final String updateJson = updateJsonRequest(jsonRootNode, correlationId);
					
					//Start:: Change for POST request Error for correlationId
					byte[] bytes = updateJson.getBytes("UTF-8");
                    ctx.setRequest(new HttpServletRequestWrapper(ctx.getRequest()) {
                    @Override
                    public ServletInputStream getInputStream() throws IOException {
                                              return new ServletInputStreamWrapper(bytes);
                                       }

                                       @Override
                                       public int getContentLength() {
                                       return bytes.length;
                                       }

                                       @Override
                                       public long getContentLengthLong() {
                                              return bytes.length;
                                       }
                                 }); 
	

					// create new request with updated json
					//HttpServletRequestWrapper httpServletRequestWrapper = createRequestWrapper(request, updateJson);
					//ctx.setRequest(httpServletRequestWrapper);
					//End :: Change for POST request Error for correlationId
				} else {
					LOGGER.info("CorrelationId found in request. {}", correlationId);
				}
			}
		} catch (IOException e) {
			LOGGER.error("### IO Exception occur while reset the request for Correlation id is {} and exception is {} ",
					correlationId, e);
			throw new CorrelationException(e.getMessage(), correlationId);
		} catch (Exception e) {
			LOGGER.error("### Exception occur while reset the request for Correlation id is {} and exception is {} ",
					correlationId, e);
			throw new CorrelationException(e.getMessage(), correlationId);
		}
	}

	/**
	 * This method is used to get the correlationId
	 * 
	 * @param request
	 * @return String
	 */
	public static String getCorrelationId(HttpServletRequest request) {
		//  RAC-968 change
		if (HTTP_GET_METHOD.equalsIgnoreCase(request.getMethod()) || HTTP_DELETE_METHOD.equalsIgnoreCase(request.getMethod())) {
			String correlationId = request.getParameter(CORRELATION_ID);
			return StringUtils.isBlank(correlationId) ? generateCorrelationId() : correlationId;
		} else {
			try {
				String correlationId = getCorrelationId(request.getInputStream());
				return StringUtils.isBlank(correlationId) ? generateCorrelationId() : correlationId;
			} catch (IOException e) {
				LOGGER.error("Error occurs while fetching input stream and exception is {} ", e);
			}
		}
		return generateCorrelationId();
	}

	/**
	 * This method is used to get Correlation Id from Input stream
	 * 
	 * @param inputStream
	 * @return String
	 */
	public static String getCorrelationId(InputStream inputStream) {
		JsonNode jsonRootNode;
		try {
			jsonRootNode = JsonUtil.readJson(inputStream);
			return jsonRootNode.path(CORRELATION_ID).textValue();
		} catch (IOException e) {
			LOGGER.error("Body is empty and exception is {}", e);
		}
		return null;
	}

	/**
	 * This method is used to get Correlation Id form request Context
	 * 
	 * @param ctx
	 * @return
	 * @throws Exception
	 */
	public static String getCorrelationId(RequestContext ctx) {
		HttpServletRequest request = ctx.getRequest();
		String correlationId = null;
		//  RAC-968 change
		if (HTTP_GET_METHOD.equalsIgnoreCase(request.getMethod()) || HTTP_DELETE_METHOD.equalsIgnoreCase(request.getMethod())) {
			Map<String, List<String>> queryParams = ctx.getRequestQueryParams();
			if (null != queryParams && queryParams.containsKey(CORRELATION_ID)) {
				List<String> id = (LinkedList<String>) queryParams.get(CORRELATION_ID);
				correlationId = id.get(0);
			}
			if (StringUtils.isBlank(correlationId)) {
				correlationId = generateCorrelationId();
			}
		} else {
			correlationId = getCorrelationId(request);
		}
		return correlationId;
	}

}


// Comment for POST request Error for correlationId
/**
 * This is the Wrapper class of ServletInputStream to set the input stream
 * 
 * @author vijay.bq.kumar
 *
 */
 /*
class ServletInputStreamWrapper extends ServletInputStream {

	private byte[] data;
	private int idx = 0;

	ServletInputStreamWrapper(byte[] data) {
		if (data == null)
			data = new byte[0];
		this.data = data;
	}

	@Override
	public int read() throws IOException {
		if (idx == data.length)
			return -1;
		return data[idx++];
	}

	
	@Override
	public boolean isFinished() {
		return this.isFinished();
	}

	@Override
	public boolean isReady() {
		return this.isReady();
	}

	@Override
	public void setReadListener(ReadListener arg0) {
		
	}

}*/

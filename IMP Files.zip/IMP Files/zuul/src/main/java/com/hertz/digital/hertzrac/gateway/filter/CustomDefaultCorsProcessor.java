package com.hertz.digital.hertzrac.gateway.filter;

import static com.hertz.digital.hertzrac.gateway.util.Constants.CORRELATION_ID;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.web.cors.DefaultCorsProcessor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.hertz.digital.hertzrac.gateway.exception.ExceptionEnum;
import com.hertz.digital.hertzrac.gateway.util.CorrelationProcessorUtil;
import com.hertz.digital.hertzrac.gateway.util.ErrorUtil;
import com.hertz.digital.hertzrac.gateway.util.JsonUtil;

/**
 * Overrides the default spring cors processor
 * in order to send out the customised error response
 *
 */

public class CustomDefaultCorsProcessor extends DefaultCorsProcessor {

	private static final String CORS_ERROR_MESSAGE = "Invalid CORS request";

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomDefaultCorsProcessor.class);

	/**
	 * Invoked when one of the CORS checks failed.
	 * 
	 * 
	 */
	@Override
	protected void rejectRequest(ServerHttpResponse response) throws IOException {
		ServletServerHttpResponse res = (ServletServerHttpResponse) response;
		response.setStatusCode(HttpStatus.FORBIDDEN);
		res.getServletResponse().setContentType("application/json;charset=UTF-8");
		res.getServletResponse().getWriter().write(sendError(res.getServletResponse()));
	}

	public String sendError(HttpServletResponse response) throws JsonProcessingException {
		ObjectNode jsonRootNode = JsonUtil.createNode();
		String correlationId = CorrelationProcessorUtil.generateCorrelationId();
		jsonRootNode.put(CORRELATION_ID, correlationId);
		ExceptionEnum enumValue = ExceptionEnum.valueOf("INVALID_CORS_REQUEST");
		ErrorUtil.setDebugJsonNode(jsonRootNode, enumValue.getErrorCode(), enumValue.getErrorMessage(),
				CORS_ERROR_MESSAGE);
		ObjectMapper mapper = new ObjectMapper();
		LOGGER.info(" Invalid cors request " + correlationId);
		return mapper.writeValueAsString(jsonRootNode);
	}

}

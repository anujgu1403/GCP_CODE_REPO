package com.hertz.digital.hertzrac.gateway.filter;

import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.util.StringUtils;

import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.DirectDecrypter;

import static org.apache.commons.codec.binary.Hex.*;

/**
 * 
 * Request wrapper to decrypt the token *
 *
 */


public class HttpServletRequestHeaderWrapper extends HttpServletRequestWrapper {

	private String secretKey;
	private HttpServletRequest request;

	public HttpServletRequestHeaderWrapper(HttpServletRequest request, String secretKey) {
		super(request);
		this.secretKey = secretKey;
		this.request = request;
	}

	@Override
	public Enumeration<String> getHeaders(String name) {
		List<String> headerValues = Collections.list(super.getHeaders(name));
		int index = 0;
		if ("Authorization".equals(name)) {
			for (String value : headerValues) {
				if ((value.toLowerCase().startsWith(OAuth2AccessToken.BEARER_TYPE.toLowerCase()))) {
					try {
						String token = value.substring(OAuth2AccessToken.BEARER_TYPE.length()).trim();
						if (request.getRequestURI().endsWith("/api/token")
								&& (StringUtils.countOccurrencesOf(token, ".") <= 2)) {
							headerValues.set(index, "Opaque " + token); // Token verification is not required
						} else {
							headerValues.set(index, OAuth2AccessToken.BEARER_TYPE + " " + decryptToken(token));
						}

					} catch (Exception e) {
						throw new BadCredentialsException("Could not decrypt token");
					}
					break;
				}
				index++;
			}
		}
		return Collections.enumeration(headerValues);
	}
	

	private String decryptToken(String token) throws Exception {
		JWEObject jweObject = JWEObject.parse(token);
		byte[] encoded = decodeHex(secretKey.toCharArray());
		jweObject.decrypt(new DirectDecrypter(new SecretKeySpec(encoded, "AES").getEncoded()));
		Payload payload = jweObject.getPayload();
		return payload.toString();

	}

}
